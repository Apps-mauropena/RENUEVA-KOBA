
import React, { useState, useMemo } from 'react';
import { INITIAL_CONFIG, IVA_RATE } from './constants';
import { ProjectConfig, QuoteResult, MaterialType, QuoteItem } from './types';
import { processNaturalLanguage } from './services/geminiService';
import { 
  Calculator, 
  Send, 
  Printer, 
  RefreshCw,
  PlusCircle,
  Tag,
  Clock,
  Briefcase,
  ArrowRight,
  Truck,
  ChevronDown,
  AlertTriangle,
  Info,
  DollarSign,
  Layers,
  Users
} from 'lucide-react';

export default function App() {
  const [config, setConfig] = useState<ProjectConfig>(INITIAL_CONFIG);
  const [prompt, setPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const result: QuoteResult = useMemo(() => {
    const mainMaterial = config.materials[config.selectedMaterial];
    const sealerMaterial = config.materials['Sellador'];
    const m2 = config.m2;
    const items: QuoteItem[] = [];

    // 1. Principal
    const mainBuckets = Math.ceil(m2 / mainMaterial.yield);
    items.push({
      concept: config.selectedMaterial,
      detail: `Cobertura total para ${m2} m²`,
      quantity: `${mainBuckets} Cub.`,
      unitPrice: mainMaterial.price,
      total: mainBuckets * mainMaterial.price,
      brand: mainMaterial.brand,
      yieldDisplay: `${mainMaterial.yield} m²/c`
    });

    // 2. Sellador
    const sealerBuckets = Math.ceil(m2 / sealerMaterial.yield);
    items.push({
      concept: 'Sellador Primario',
      detail: 'Base de adherencia obligatoria',
      quantity: `${sealerBuckets} Cub.`,
      unitPrice: sealerMaterial.price,
      total: sealerBuckets * sealerMaterial.price,
      brand: sealerMaterial.brand,
      yieldDisplay: `${sealerMaterial.yield} m²/c`
    });

    // 3. Auxiliar
    items.push({
      concept: 'Material Auxiliar',
      detail: 'Rodillos, brochas, cintas y masking',
      quantity: `${m2} m²`,
      unitPrice: config.auxMaterialRate / 100,
      total: (m2 / 100) * config.auxMaterialRate,
      brand: 'Varios',
      yieldDisplay: 'N/A'
    });

    // 4. Andamios
    const hasScaffold = config.scaffoldCount > 0;
    items.push({
      concept: 'Renta de andamio',
      detail: 'Torres certificadas para altura',
      quantity: hasScaffold ? `${config.scaffoldCount} Und.` : '0',
      unitPrice: config.scaffoldDailyRate,
      total: hasScaffold ? (config.scaffoldCount * config.scaffoldDailyRate * config.scaffoldDays) : 0,
      brand: hasScaffold ? 'SÍ' : 'NO',
      yieldDisplay: hasScaffold ? `${config.scaffoldDays} Días` : '0 D'
    });

    // 5. Mano de Obra
    items.push({
      concept: 'Mano de Obra Especializada',
      detail: 'Ejecución técnica de aplicación',
      quantity: `${config.numWorkers * config.workDays} Jorn.`,
      unitPrice: config.workerDailyRate,
      total: config.numWorkers * config.workerDailyRate * config.workDays,
      brand: `${config.numWorkers} Trab.`,
      yieldDisplay: `${config.workDays} Días`
    });

    // 6. Albañilería (Advertencia Roja)
    if (config.masonryRepairEnabled) {
      items.push({
        concept: 'Gastos por reparaciones albañilería',
        detail: 'DAÑO ESTRUCTURAL: Reparación de paredes rotas, resanes profundos y parches antes de pintar.',
        quantity: '1 Serv.',
        unitPrice: config.masonryRepairCost,
        total: config.masonryRepairCost,
        brand: 'URGENTE',
        yieldDisplay: 'Pre-Obra',
        isWarning: true
      });
    }

    // 7. Utilidad
    items.push({
      concept: 'Supervisión y Administración',
      detail: 'Dirección técnica Mauro y Omar',
      quantity: `${m2} m²`,
      unitPrice: config.profitRate,
      total: m2 * config.profitRate,
      brand: 'Ingeniería',
      yieldDisplay: 'N/A'
    });

    const subtotal = items.reduce((acc, item) => acc + item.total, 0);
    return { items, subtotal, iva: subtotal * IVA_RATE, total: subtotal * (1 + IVA_RATE) };
  }, [config]);

  const handleAiSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    setIsProcessing(true);
    const updates = await processNaturalLanguage(prompt, config);
    if (updates) {
      setConfig(prev => {
        const next = { ...prev, materials: { ...prev.materials } };
        Object.assign(next, updates);
        if (updates.brand || updates.price || updates.yield) {
          const target = prompt.toLowerCase().includes('sellador') ? 'Sellador' : next.selectedMaterial;
          next.materials[target] = { ...next.materials[target], ...updates };
        }
        return next;
      });
      setPrompt('');
    }
    setIsProcessing(false);
  };

  return (
    <div className="max-w-[1440px] mx-auto p-4 md:p-6 space-y-6">
      <header className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-slate-100 no-print">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2 rounded-xl text-white"><Briefcase className="w-6 h-6" /></div>
          <div>
            <h1 className="text-2xl font-black text-slate-800 tracking-tighter">RENUEVA KOBA</h1>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Calculador Pro v2.5</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setConfig(INITIAL_CONFIG)} className="p-2 text-slate-400 hover:bg-slate-50 rounded-lg"><RefreshCw className="w-4 h-4" /></button>
          <button onClick={() => window.print()} className="flex items-center gap-2 px-6 py-2 bg-slate-900 text-white rounded-lg font-bold text-sm">
            <Printer className="w-4 h-4" /> Imprimir Cotización
          </button>
        </div>
      </header>

      <main className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sidebar Controls (3 Columns) */}
        <div className="lg:col-span-3 space-y-4 no-print">
          <section className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 space-y-3">
            <h2 className="flex items-center gap-2 text-[10px] font-black uppercase text-slate-800"><Calculator className="w-3 h-3 text-indigo-500" /> Dimensiones</h2>
            <div className="relative">
              <input type="number" value={config.m2} onChange={(e) => setConfig(p => ({ ...p, m2: Number(e.target.value) }))}
                className="w-full p-3 bg-slate-50 border border-slate-100 rounded-xl font-black text-xl focus:ring-2 focus:ring-indigo-100 outline-none" />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300 font-black italic">M²</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {['Impermeabilizante', 'Pintura'].map((mat) => (
                <button key={mat} onClick={() => setConfig(p => ({ ...p, selectedMaterial: mat as MaterialType }))}
                  className={`py-2 rounded-xl border-2 font-black text-[10px] ${config.selectedMaterial === mat ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white text-slate-400'}`}>
                  {mat}
                </button>
              ))}
            </div>
          </section>

          <section className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 space-y-3">
            <h2 className="flex items-center gap-2 text-[10px] font-black uppercase text-slate-800"><Truck className="w-3 h-3 text-indigo-500" /> Andamiaje</h2>
            <div className="space-y-2">
              <div className="relative">
                <select value={config.scaffoldCount > 0 ? "SI" : "NO"} 
                  onChange={(e) => setConfig(p => ({ ...p, scaffoldCount: e.target.value === "SI" ? 1 : 0 }))}
                  className="w-full p-2 bg-slate-50 border border-slate-100 rounded-lg font-bold text-xs appearance-none">
                  <option value="NO">APLICA: NO</option>
                  <option value="SI">APLICA: SÍ</option>
                </select>
                <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="relative">
                  <select value={config.scaffoldDays} disabled={config.scaffoldCount === 0}
                    onChange={(e) => setConfig(p => ({ ...p, scaffoldDays: Number(e.target.value) }))}
                    className="w-full p-2 bg-slate-50 border border-slate-100 rounded-lg font-bold text-xs appearance-none disabled:opacity-30">
                    {[1,2,3,4,5,7,10,15,30].map(d => <option key={d} value={d}>{d} Días</option>)}
                  </select>
                  <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400" />
                </div>
                <div className="relative">
                  <select value={config.scaffoldDailyRate} disabled={config.scaffoldCount === 0}
                    onChange={(e) => setConfig(p => ({ ...p, scaffoldDailyRate: Number(e.target.value) }))}
                    className="w-full p-2 bg-slate-50 border border-slate-100 rounded-lg font-bold text-xs appearance-none disabled:opacity-30">
                    {[100,150,200,250,300,350,400,450,500].map(c => <option key={c} value={c}>${c}/día</option>)}
                  </select>
                  <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400" />
                </div>
              </div>
            </div>
          </section>

          <section className={`p-4 rounded-2xl border transition-all space-y-3 ${config.masonryRepairEnabled ? 'bg-rose-50 border-rose-100 ring-1 ring-rose-200' : 'bg-white border-slate-100'}`}>
            <div className="flex justify-between items-center">
              <h2 className="flex items-center gap-2 text-[10px] font-black uppercase text-slate-800"><AlertTriangle className="w-3 h-3 text-rose-500" /> Albañilería</h2>
              <button onClick={() => setConfig(p => ({ ...p, masonryRepairEnabled: !p.masonryRepairEnabled }))}
                className={`px-2 py-1 rounded text-[8px] font-black ${config.masonryRepairEnabled ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-400'}`}>
                {config.masonryRepairEnabled ? "SÍ" : "NO"}
              </button>
            </div>
            {config.masonryRepairEnabled && (
              <input type="number" placeholder="Costo reparación" value={config.masonryRepairCost} onChange={(e) => setConfig(p => ({ ...p, masonryRepairCost: Number(e.target.value) }))}
                className="w-full p-2 bg-white border border-rose-200 rounded-xl font-black text-rose-900 text-sm outline-none" />
            )}
          </section>

          <section className="bg-slate-900 p-4 rounded-2xl shadow-xl space-y-3 text-white">
            <h2 className="flex items-center gap-2 text-[10px] font-bold uppercase"><PlusCircle className="w-3 h-3 text-indigo-400" /> IA Asistente</h2>
            <form onSubmit={handleAiSubmit} className="relative">
              <input type="text" placeholder="Ej: Hay grietas profundas..." value={prompt} onChange={(e) => setPrompt(e.target.value)} disabled={isProcessing}
                className="w-full pl-3 pr-8 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs outline-none focus:ring-1 focus:ring-indigo-400" />
              <button type="submit" className="absolute right-1.5 top-1/2 -translate-y-1/2 p-1.5 bg-indigo-600 rounded-md">
                {isProcessing ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
              </button>
            </form>
          </section>
        </div>

        {/* Table Content (9 Columns) */}
        <div className="lg:col-span-9 space-y-4">
          <section className="bg-white p-6 md:p-10 rounded-3xl shadow-xl border border-slate-50 min-h-full">
            <div className="flex justify-between items-start mb-8 pb-6 border-b-2 border-slate-900">
              <div className="space-y-2">
                <div className="bg-slate-900 text-white px-2 py-1 rounded text-[8px] font-black uppercase inline-block">RK-OFFICIAL</div>
                <h2 className="text-3xl font-black text-slate-900 tracking-tighter uppercase">PRESUPUESTO DE SERVICIO</h2>
                <div className="flex gap-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">
                  <span className="flex items-center gap-1"><Tag className="w-2.5 h-2.5" /> ID: {Math.floor(Math.random()*1000)}</span>
                  <span className="flex items-center gap-1"><Clock className="w-2.5 h-2.5" /> {new Date().toLocaleDateString('es-MX')}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-3xl font-black text-indigo-600 tracking-tighter leading-none">RENUEVA</div>
                <div className="text-[10px] font-black text-slate-900 tracking-widest uppercase italic">KOBA S.A. DE C.V.</div>
              </div>
            </div>

            <div className="w-full overflow-hidden">
              <table className="w-full text-left border-collapse table-fixed">
                <thead>
                  <tr className="bg-slate-900 text-white text-[9px] font-black uppercase tracking-widest">
                    <th className="p-3 w-[25%] rounded-tl-xl">Concepto</th>
                    <th className="p-3 w-[20%]">Detalle</th>
                    <th className="p-3 w-[15%]">Plazo/Rend.</th>
                    <th className="p-3 w-[12%] text-center">Cant.</th>
                    <th className="p-3 w-[13%] text-right">Unitario</th>
                    <th className="p-3 w-[15%] text-right rounded-tr-xl">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {result.items.map((item, idx) => (
                    <tr key={idx} className={`group transition-colors ${item.isWarning ? 'bg-rose-50 hover:bg-rose-100 animate-pulse' : 'hover:bg-slate-50'}`}>
                      <td className="p-3 align-top">
                        <p className={`font-black text-xs ${item.isWarning ? 'text-rose-600' : 'text-slate-900'}`}>{item.concept}</p>
                        <p className={`text-[8px] font-bold leading-tight uppercase truncate ${item.isWarning ? 'text-rose-500 italic' : 'text-slate-400'}`}>{item.detail}</p>
                      </td>
                      <td className="p-3 align-top">
                        <div className={`p-1.5 rounded-lg border text-center ${item.isWarning ? 'bg-rose-100 border-rose-200' : 'bg-slate-50 border-slate-100'}`}>
                           <p className={`text-[9px] font-black truncate ${item.isWarning ? 'text-rose-700' : 'text-slate-600'}`}>{item.brand}</p>
                        </div>
                      </td>
                      <td className="p-3 align-top">
                        <p className={`text-[9px] font-black italic ${item.isWarning ? 'text-rose-600' : 'text-slate-500'}`}>{item.yieldDisplay}</p>
                      </td>
                      <td className="p-3 text-center align-top">
                        <span className={`text-[10px] font-black px-2 py-1 rounded ${item.isWarning ? 'bg-rose-200 text-rose-800' : 'bg-slate-100 text-slate-800'}`}>{item.quantity}</span>
                      </td>
                      <td className="p-3 text-right align-top">
                        <p className="text-[10px] font-bold text-slate-600">${item.unitPrice.toLocaleString('es-MX')}</p>
                      </td>
                      <td className="p-3 text-right align-top">
                        <p className={`text-xs font-black ${item.isWarning ? 'text-rose-700' : 'text-slate-900'}`}>${item.total.toLocaleString('es-MX')}</p>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex flex-col md:flex-row justify-between items-end mt-10 gap-8">
              <div className="w-full md:max-w-[45%] p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <p className="text-[9px] font-black text-slate-400 uppercase mb-2 flex items-center gap-1.5"><Info className="w-3 h-3" /> Cláusulas</p>
                <ul className="text-[8px] font-bold text-slate-500 space-y-1">
                  <li className="flex gap-2"><ArrowRight className="w-2.5 h-2.5 text-indigo-500" /> Precios sujetos a cambios sin previo aviso.</li>
                  <li className="flex gap-2"><ArrowRight className="w-2.5 h-2.5 text-indigo-500" /> Anticipo del 50% para inicio de obra.</li>
                  <li className="flex gap-2"><ArrowRight className="w-2.5 h-2.5 text-indigo-500" /> Garantía por escrito según material seleccionado.</li>
                </ul>
              </div>
              <div className="min-w-[320px] space-y-2">
                <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  <span>Subtotal Neto</span>
                  <span className="text-slate-900">${result.subtotal.toLocaleString('es-MX', { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-[10px] font-black text-slate-300 uppercase tracking-widest">
                  <span>IVA Trasladado (16%)</span>
                  <span>${result.iva.toLocaleString('es-MX', { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="h-0.5 bg-slate-900 my-2"></div>
                <div className="flex justify-between items-baseline">
                  <span className="text-sm font-black italic uppercase text-slate-900">Importe Total</span>
                  <div className="text-right">
                    <span className="text-4xl font-black text-slate-900 tracking-tighter">${result.total.toLocaleString('es-MX', { maximumFractionDigits: 0 })}</span>
                    <span className="text-[10px] font-black text-slate-400 ml-1">MXN</span>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>

      <footer className="no-print bg-slate-900/95 backdrop-blur-xl p-4 rounded-2xl flex flex-wrap justify-between items-center sticky bottom-4 z-50 ring-1 ring-white/10 max-w-6xl mx-auto shadow-2xl">
        <div className="flex items-center gap-8 pl-4">
          <div className="flex flex-col"><p className="text-[8px] font-black text-indigo-300 uppercase">Utilidad</p><p className="text-sm font-black text-white">${(config.m2 * config.profitRate).toLocaleString()}</p></div>
          <div className="w-px h-6 bg-white/10"></div>
          <div className="flex flex-col"><p className="text-[8px] font-black text-emerald-300 uppercase">Materiales</p><p className="text-sm font-black text-white">${(result.subtotal - (config.numWorkers * config.workerDailyRate * config.workDays) - (config.m2 * config.profitRate)).toLocaleString()}</p></div>
          <div className="w-px h-6 bg-white/10"></div>
          <div className="flex flex-col"><p className="text-[8px] font-black text-rose-300 uppercase">Jornadas</p><p className="text-sm font-black text-white">{config.numWorkers * config.workDays}</p></div>
        </div>
        <div className="pr-4 text-right">
          <p className="text-[8px] font-black text-slate-400 uppercase mb-0.5">Monto de Liquidación</p>
          <p className="text-3xl font-black text-white tracking-tighter leading-none">${result.total.toLocaleString('es-MX', { maximumFractionDigits: 0 })}</p>
        </div>
      </footer>
    </div>
  );
}
