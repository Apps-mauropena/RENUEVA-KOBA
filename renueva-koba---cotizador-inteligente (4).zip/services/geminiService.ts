
import { GoogleGenAI, Type } from "@google/genai";
import { ProjectConfig, AIUpdates } from "../types";

export const processNaturalLanguage = async (prompt: string, currentConfig: ProjectConfig): Promise<AIUpdates | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const systemInstruction = `
    Eres el asistente técnico de "Renueva Koba". Extrae cambios de presupuesto de forma lógica.
    REGLA DE ORO: El rendimiento del impermeabilizante es siempre 34 m2 por cubeta.
    Detecta si el usuario menciona paredes rotas, grietas profundas o daños estructurales para activar "masonryRepairEnabled" y asignar un "masonryRepairCost".
    Campos: m2, selectedMaterial (Impermeabilizante/Pintura), yield, price, brand, profitRate, numWorkers, workerDailyRate, workDays, scaffoldCount, scaffoldDailyRate, scaffoldDays, masonryRepairEnabled, masonryRepairCost.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Contexto actual: ${JSON.stringify(currentConfig)}. Petición: ${prompt}`,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            m2: { type: Type.NUMBER },
            selectedMaterial: { type: Type.STRING },
            yield: { type: Type.NUMBER },
            price: { type: Type.NUMBER },
            brand: { type: Type.STRING },
            numWorkers: { type: Type.NUMBER },
            workerDailyRate: { type: Type.NUMBER },
            workDays: { type: Type.NUMBER },
            scaffoldCount: { type: Type.NUMBER },
            scaffoldDailyRate: { type: Type.NUMBER },
            scaffoldDays: { type: Type.NUMBER },
            masonryRepairEnabled: { type: Type.BOOLEAN },
            masonryRepairCost: { type: Type.NUMBER }
          }
        }
      }
    });

    return response.text ? JSON.parse(response.text.trim()) : null;
  } catch (error) {
    console.error("AI Error:", error);
    return null;
  }
};
