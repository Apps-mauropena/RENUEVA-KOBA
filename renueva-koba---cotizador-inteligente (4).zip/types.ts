
export type MaterialType = 'Impermeabilizante' | 'Pintura' | 'Sellador';

export interface MaterialConfig {
  name: MaterialType;
  yield: number; // m2 per bucket
  price: number; // price per bucket
  brand: string; // bucket brand
}

export interface Worker {
  id: string;
  name: string;
  dailyRate: number;
}

export interface ProjectConfig {
  m2: number;
  selectedMaterial: MaterialType;
  auxMaterialRate: number;
  profitRate: number;
  materials: Record<MaterialType, MaterialConfig>;
  workers: Worker[];
  numWorkers: number;
  workerDailyRate: number;
  workDays: number;
  scaffoldCount: number;
  scaffoldDailyRate: number;
  scaffoldDays: number;
  masonryRepairEnabled: boolean;
  masonryRepairCost: number;
}

export interface AIUpdates {
  m2?: number;
  selectedMaterial?: string;
  yield?: number;
  price?: number;
  brand?: string;
  profitRate?: number;
  numWorkers?: number;
  workerDailyRate?: number;
  workDays?: number;
  scaffoldCount?: number;
  scaffoldDailyRate?: number;
  scaffoldDays?: number;
  masonryRepairEnabled?: boolean;
  masonryRepairCost?: number;
}

export interface QuoteItem {
  concept: string;
  detail: string;
  quantity: string | number;
  unitPrice: number;
  total: number;
  brand?: string; 
  yieldDisplay?: string;
  isWarning?: boolean;
}

export interface QuoteResult {
  items: QuoteItem[];
  subtotal: number;
  iva: number;
  total: number;
}
